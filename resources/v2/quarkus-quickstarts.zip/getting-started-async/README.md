Quarkus guide: https://quarkus.io/guides/getting-started
