Quarkus guide: https://quarkus.io/guides/cache
