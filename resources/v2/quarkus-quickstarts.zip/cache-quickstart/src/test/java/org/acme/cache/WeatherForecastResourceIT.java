package org.acme.cache;

import io.quarkus.test.junit.QuarkusIntegrationTest;

@QuarkusIntegrationTest
public class WeatherForecastResourceIT extends WeatherForecastResourceTest {

    // Execute the same tests but in native mode.
}
