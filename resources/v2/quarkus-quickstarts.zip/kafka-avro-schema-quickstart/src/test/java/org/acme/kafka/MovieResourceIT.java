package org.acme.kafka;

import io.quarkus.test.junit.QuarkusIntegrationTest;

@QuarkusIntegrationTest
public class MovieResourceIT extends MovieResourceTest {

    // Execute the same tests but in native mode.
}
