This quickstart is empty.  Examples for Funqy Azure Functions are generated from a maven archetype.

Quarkus guide: https://quarkus.io/guides/azure-functions-http
