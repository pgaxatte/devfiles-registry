package org.acme.ses;

import io.quarkus.test.junit.QuarkusIntegrationTest;

@QuarkusIntegrationTest
public class SesResourcesIT extends SesResourcesTest {
    // Runs the same tests as the parent class
}
