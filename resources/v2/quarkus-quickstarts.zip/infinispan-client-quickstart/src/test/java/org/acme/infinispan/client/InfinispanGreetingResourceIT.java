package org.acme.infinispan.client;

import io.quarkus.test.junit.QuarkusIntegrationTest;

@QuarkusIntegrationTest
public class InfinispanGreetingResourceIT extends InfinispanGreetingResourceTest {
}
