package org.acme.jms;

import io.quarkus.test.junit.QuarkusIntegrationTest;

@QuarkusIntegrationTest
public class PriceTestIT extends PriceTest {
}
